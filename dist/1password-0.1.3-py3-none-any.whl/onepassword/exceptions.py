class OnePasswordForgottenPassword(Exception):
    pass
